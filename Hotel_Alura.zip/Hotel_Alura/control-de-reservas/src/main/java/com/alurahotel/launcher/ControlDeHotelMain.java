package com.alurahotel.launcher;

import com.alurahotel.view.Login;

public class ControlDeHotelMain {
	
	public static void main(String[] args) {
		Login loginFrame = new Login();
		loginFrame.setVisible(true);
	}

}
